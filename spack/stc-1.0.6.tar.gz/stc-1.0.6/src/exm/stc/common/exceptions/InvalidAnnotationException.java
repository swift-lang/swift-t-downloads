/*
 * Copyright 2013 University of Chicago and Argonne National Laboratory
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License
 */
package exm.stc.common.exceptions;

import exm.stc.frontend.Context;

public class InvalidAnnotationException extends UserException {

  private static final long serialVersionUID = 1;

  public InvalidAnnotationException(Context context, String msg) {
    super(context, msg);
  }
  
  public InvalidAnnotationException(Context context, String partOfCode,
                                    String annotation, boolean keyValue) {
    super(context, makeMessage(partOfCode, annotation, keyValue, null));
  }
  
  public InvalidAnnotationException(Context context, String partOfCode,
      String annotation, boolean keyValue, String validAnnotations) {
    super(context, makeMessage(partOfCode, annotation, keyValue, validAnnotations));
  }

  private static String makeMessage(String partOfCode, String annotation,
      boolean keyValue, String validAnnotations) {
    String msg; 
    if (keyValue) {
      msg = "Invalid key-value annotation @" + annotation + "=...";
    } else { 
      msg = "Invalid annotation @" + annotation;
    }
    msg += " attached to " + partOfCode;
    if (validAnnotations != null) {
      msg += ".  Valid annotations are: " + validAnnotations;
    }
    return msg;
  }

}
