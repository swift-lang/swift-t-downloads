# Copyright 2013 University of Chicago and Argonne National Laboratory
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License

# This file debug-tokens.tcl.in is expected to be regularly edited
# to control debugging output.  It is sourced by debug-auto.tcl
# The variable INPUT is converted to an array by debug-auto.tcl
# Each token maps to ON or OFF to indicate debugging
# If you edit this file, you must re-run ./configure or ./config.status

set INPUT {
    TURBINE OFF
    TCL_TURBINE OFF
    ADLB OFF
    CACHE OFF
    EXECUTOR OFF
    COASTER OFF
}
