
# Flags for XLC

STD=""
PIC=-qpic
SHARED=-qmkshrobj
