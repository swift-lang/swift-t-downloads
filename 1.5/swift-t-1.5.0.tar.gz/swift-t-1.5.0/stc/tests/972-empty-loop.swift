
// COMPILE-ONLY-TEST
main {
    for (; true; ) {
        int j = 1;
    }
}
