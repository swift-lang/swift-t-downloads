#!/bin/bash
rm 4091-A
rm 4091-B
