// THIS-TEST-SHOULD-NOT-COMPILE

main () {
    // Can't assign URL to file
    file f = input_url("http://url.com");

}
