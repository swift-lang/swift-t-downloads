
// THIS-TEST-SHOULD-NOT-RUN
import io;
import sys;

main {
  // Invalid trailing character
  int N = toint("1232b");
  trace(N);
}
