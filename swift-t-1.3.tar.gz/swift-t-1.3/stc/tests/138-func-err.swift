
// THIS-TEST-SHOULD-NOT-COMPILE
main {

  import something;
}
