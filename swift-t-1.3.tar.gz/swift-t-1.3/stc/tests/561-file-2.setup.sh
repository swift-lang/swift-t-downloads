echo "hello world!" > ./alice.txt
echo "bye world!" > ./joe.txt
