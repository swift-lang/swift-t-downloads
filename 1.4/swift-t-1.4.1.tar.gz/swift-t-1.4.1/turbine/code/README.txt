Turbine is a runtime library that supports distributed execution of
task-parallel data-flow-based applications.

Mailing List
============

https://groups.google.com/forum/#!forum/swift-t-user

Contact
=======
Justin Wozniak: wozniak@mcs.anl.gov
