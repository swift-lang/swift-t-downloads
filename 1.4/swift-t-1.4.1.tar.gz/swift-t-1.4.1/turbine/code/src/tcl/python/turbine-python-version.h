


// The Python version is: 2.7
#include <python2.7/Python.h>
