/* src/mpe-settings.h.  Generated from mpe-settings.h.in by configure.  */

#ifndef MPE_SETTINGS_H
#define MPE_SETTINGS_H

#define ADLB_ENABLE_MPE "no"

#endif
