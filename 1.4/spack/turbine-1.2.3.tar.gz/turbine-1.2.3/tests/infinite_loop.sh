#!/bin/bash

while true ; do date ; done
