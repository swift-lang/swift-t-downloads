

#include <math.h>
#include <stdio.h>


static int get_pad(int max)
{
  double d = log(max+1)/log(10);
  double c = ceil(d);
  printf("n: %6i d: %f c: %f", max, d);

  return rintl(c);
}

int main()
{
  int n;
  n = 1;
  printf("%i %i\n", n, get_pad(n));

  n = 2;
  printf("%i %i\n", n, get_pad(n));
  n = 9;
  printf("%i %i\n", n, get_pad(n));
  n = 10;
  printf("%i %i\n", n, get_pad(n));
  n = 11;
  printf("%i %i\n", n, get_pad(n));
  n = 90;
  printf("%i %i\n", n, get_pad(n));


  n = 99;
  printf("%i %i\n", n, get_pad(n));

  n = 100;
  printf("%i %i\n", n, get_pad(n));

  n = 999;
  printf("%i %i\n", n, get_pad(n));
  n = 1000;
  printf("%i %i\n", n, get_pad(n));

  n = 90;
  printf("%i %i\n", n, get_pad(n));


  return 0;
}
