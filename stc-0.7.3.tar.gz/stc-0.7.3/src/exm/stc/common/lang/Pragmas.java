package exm.stc.common.lang;

/**
 * Keep names of pragmas in one place.
 */
public class Pragmas {
  public static final String WORK_TYPE_DEF = "worktypedef";
  public static final String APP_EXECUTOR_DEF = "appexecdef";
}
