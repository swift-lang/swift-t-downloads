
/**
 * TURBINE-VERSION.H.IN
 *
 * Allows config.status to inject the TURBINE_VERSION
 * Edit this file to update the required ADLB, c-utils versions
 * */

#pragma once

/** Version from version.txt as a string */
#define TURBINE_VERSION "1.4.2"

/** Required ADLB version */
#define ADLB_REQUIRED_VERSION "1.0.1"

/** Required c-utils version */
#define C_UTILS_REQUIRED_VERSION "0.6.1"
