
main
{
  int a;
  a = 1;

  {
    int b;
    b = 1;
    trace(b);
  }

  {
    int b;
    b = 1;
    trace(b);
  }

  trace(a);
}
