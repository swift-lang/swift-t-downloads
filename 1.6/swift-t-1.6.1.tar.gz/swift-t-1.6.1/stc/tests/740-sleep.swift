
import io;
import sys;

main
{
  void v = sleep(0.5);
  int i = zero(v);
  printf("zero: %i\n", i);
}
