// Minimal test for nested array insertion
() f () {
    int A[][];
    A[0][0] = 1;
    trace(A[0][0]);
}

main {
    f();
}
