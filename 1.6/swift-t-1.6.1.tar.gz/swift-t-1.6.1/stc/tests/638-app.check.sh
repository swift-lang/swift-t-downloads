#!/usr/bin/env bash
# clean up files created by setup.sh
rm -f jumped over the lazy dog
