rm test-317-*.data input.txt
