
import math;

main
{
  int n = 3;
  int d = 2;

  int T = toInt(pow_integer(n,d));

  foreach i in [0:T-1]
  {
    trace(i);
  }
}
