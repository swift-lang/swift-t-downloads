import assert;
// SKIP-THIS-TEST

main () {

  string t4 =
"""
aaa \\
""";
  assertEqual(t4, "\naaa \\\n", "t4");
  }
