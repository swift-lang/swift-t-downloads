string echo = "echo";
app f(string s) {
  echo s;
}
f("HELLO");
