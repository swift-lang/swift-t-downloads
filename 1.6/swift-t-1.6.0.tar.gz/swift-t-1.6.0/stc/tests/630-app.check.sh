rm 630-helloworld.txt
