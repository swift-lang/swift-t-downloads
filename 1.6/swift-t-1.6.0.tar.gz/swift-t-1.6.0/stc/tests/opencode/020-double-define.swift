
# THIS-TEST-SHOULD-FAIL
int i;
int i;
i = 2;
