
// THIS-TEST-SHOULD-NOT-COMPILE
// Can't use blobs as keys


main {
    float A[blob];
}
