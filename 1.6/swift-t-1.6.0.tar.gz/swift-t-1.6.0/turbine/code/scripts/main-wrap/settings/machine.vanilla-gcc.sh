
# VANILLA

TURBINE_HOME=$( cd $GENLEAF_HOME/../.. ; /bin/pwd )
source $TURBINE_HOME/scripts/turbine-build-config.sh

CC=gcc
STC=stc

source $GENLEAF_HOME/settings/flags.gcc.sh
