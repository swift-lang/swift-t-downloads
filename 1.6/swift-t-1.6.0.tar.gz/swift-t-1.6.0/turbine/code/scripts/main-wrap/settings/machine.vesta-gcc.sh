
# VESTA GCC

TCL_HOME=/home/wozniak/Public/tcl-8.5.12-bgq
TCL_VERSION=8.5

CC=/bgsys/drivers/ppcfloor/gnu-linux/bin/powerpc64-bgq-linux-gcc
STC=/home/wozniak/Public/sfw/stc/bin/stc

TURBINE_HOME=/home/wozniak/Public/sfw/turbine

source $GENLEAF_HOME/settings/flags.gcc.sh
