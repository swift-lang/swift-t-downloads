
/**
 * ADLB-VERSION.H
 *
 * Allows config.status to inject the ADLB_VERSION
 * Edit this file to update the required c-utils version
 * */

#pragma once

/** Version from version.txt as a string */
#define ADLB_VERSION "1.0.1"

/** Required c-utils version */
#define C_UTILS_REQUIRED_VERSION "0.6.1"
