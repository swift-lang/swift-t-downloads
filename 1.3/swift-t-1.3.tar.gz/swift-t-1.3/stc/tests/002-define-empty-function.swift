
(int x) myfun (int y) {
    x = 0;

}


main {


}
