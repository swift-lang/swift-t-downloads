rm 5601-*.txt
