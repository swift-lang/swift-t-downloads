package exm.stc.jvm.runtime;

import org.apache.log4j.Logger;

public class JVMRuntime {

  public static Logger getLogger() {
    return Logger.getLogger(JVMRuntime.class);
  }
}
